package Visao;
import Modelo.modelo;

import javax.swing.*;

public class Media_Notas {
    public static void main(String[] args) {
        modelo M = new modelo();

        M.setNota1(Float.parseFloat(JOptionPane.showInputDialog(null, "Digite a Nota 1 : ")));
        M.setNota2(Float.parseFloat(JOptionPane.showInputDialog(null, "Digite a Nota 2 : ")));
        M.setNota3(Float.parseFloat(JOptionPane.showInputDialog(null, "Digite a Nota 3 : ")));
        M.setNota4(Float.parseFloat(JOptionPane.showInputDialog(null, "Digite a Nota 4 : ")));

        float Media = M.CalculaMedia();
        JOptionPane.showMessageDialog(null,"A medias das Notas é : " + Media);
    }
}
