package Visao;
import Modelo.modelo;

import javax.swing.*;

public class visao {
    public static void main(String[] args) {
        modelo M = new modelo();

        M.setNota1(Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o numero 1 : ")));
        M.setNota2(Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o numero 2 : ")));
        M.setNota3(Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o numero 3 : ")));

        float Maior = M.Comparar_N();
        JOptionPane.showMessageDialog(null,"O maior numero é : " + Maior);
    }
}