package Modelo;

public class PeT {
    private double Altura;
    private double Largura;
    private static final double CONSUMO_TINTA_ML = 300;
    private static final double LITROS_POR_LATA = 2;


    public double AreaParede() {
        return Altura * Largura;
    }

    public int Latas() {
        double area = AreaParede();
        double Consumo = (area * CONSUMO_TINTA_ML) / 1000;
        return (int) Math.ceil(Consumo / LITROS_POR_LATA);
    }


    public double getAltura() {
        return Altura;
    }
    public void setAltura(double altura) {
        this.Altura = altura;
    }

    public double getLargura() {
        return Largura;
    }

    public void setLargura(double largura) {
        this.Largura = largura;
    }
}

