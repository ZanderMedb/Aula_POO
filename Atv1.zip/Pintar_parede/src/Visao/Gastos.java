package Visao;

import Modelo.PeT;
import javax.swing.*;

public class Gastos {
    public static void main(String[] args) {
        PeT Tinta = new PeT();

        Tinta.setAltura(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite a Altura da parede: ")));;
        Tinta.setLargura(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite a Largura da parede: ")));

        double Area = Tinta.AreaParede();
        double Calculo = Tinta.Latas();

        JOptionPane.showMessageDialog(null, "A quantidade de latas de Tinta necessarias é : " + Calculo + " Latas");

        System.out.println(Calculo);
    }
}
