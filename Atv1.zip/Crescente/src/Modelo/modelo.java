package Modelo;

public class modelo {

    private int nota1;
    private int nota2;
    private int  nota3;
    private int maior;
    private int meio;
    private int menor;

    public void Comparar_N() {
        if (nota1 <= nota2 && nota1 <= nota3) {
            menor = nota1;
            if (nota2 <= nota3) {
                meio = nota2;
                maior = nota3;
            } else {
                meio = nota3;
                maior = nota2;
            }
        } else if (nota2 <= nota1 && nota2 <= nota3) {
            menor = nota2;
            if (nota1 <= nota3) {
                meio = nota1;
                maior = nota3;
            } else {
                meio = nota3;
                maior = nota1;
            }
        } else {
            menor = nota3;
            if (nota1 <= nota2) {
                meio = nota1;
                maior = nota2;
            } else {
                meio = nota2;
                maior = nota1;
            }
        }

    }

    // Getters e Setters
    public int getNota1() {
        return nota1;
    }

    public void setNota1(int nota1) {
        this.nota1 = nota1;
    }

    public int getNota2() {
        return nota2;
    }

    public void setNota2(int nota2) {
        this.nota2 = nota2;
    }

    public int getNota3() {
        return nota3;
    }

    public void setNota3(int nota3) {
        this.nota3 = nota3;
    }

    public int getMaior() {
        return maior;
    }

    public void setMaior(int maior) {
        this.maior = maior;
    }

    public int getMeio() {
        return meio;
    }

    public void setMeio(int meio) {
        this.meio = meio;
    }

    public int getMenor() {
        return menor;
    }

    public void setMenor(int menor) {
        this.menor = menor;
    }
}

