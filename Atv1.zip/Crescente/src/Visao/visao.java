package Visao;
import Modelo.modelo;

import javax.swing.*;

public class visao {
    public static void main(String[] args) {
        modelo M = new modelo();

        M.setNota1(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o numero 1 : ")));
        M.setNota2(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o numero 2 : ")));
        M.setNota3(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o numero 3 : ")));

        M.Comparar_N();

        String resultado = "Números em ordem crescente: " + M.getMenor() + ", " + M.getMeio() + ", " + M.getMaior();
        JOptionPane.showMessageDialog(null, resultado);
    }
}