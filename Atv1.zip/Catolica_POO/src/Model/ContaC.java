package Model;

import com.sun.jdi.event.BreakpointEvent;
import com.sun.source.tree.BreakTree;

public class ContaC {
    private int numero;
    private double saldo;
    private double limite;
    private String cliente;
    private double novoSaldo;
    // Corrige a lógica para subtrair o valor do saque do saldo

    //public void saqueConta(double valorSaque) {
    //        if (valorSaque <= saldo + limite) {
    //            saldo -= valorSaque;
    //            System.out.println("Saque realizado com sucesso.");
    //        } else {
    //            System.out.println("Saldo insuficiente para o saque. Transação bloqueada.");
    //        }
    //    }
    //}

    public boolean saqueConta(double valorSaque) {
            if (valorSaque > this.saldo) { //usar o this para pegar o conteudo dentro de --> "saldo"
                double novoSaldo = saldo - valorSaque;
                System.out.println("!!TRANSACAO BLOQUEADA!!");
                return false;
            } else {
                double novoSaldo = saldo-valorSaque;
                saldo = novoSaldo;
                return true;
            }
        }

    // Corrige a lógica para adicionar o valor do depósito ao saldo
    public void depositoConta(double valorDeposito) {
        saldo += valorDeposito;
    }

    public int getNumero() {
        return numero;
    }

    // Corrige a atribuição dentro do setter
    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getCliente() {
        return cliente;
    }

    // Corrige a atribuição dentro do setter
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public double getSaldo() {
        return saldo;
    }

    // Corrige a atribuição dentro do setter
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getLimite() {
        return limite;
    }

    // Corrige a atribuição dentro do setter
    public void setLimite(double limite) {
        this.limite = limite;
    }
}

