package View;

import Model.ContaC;
import javax.swing.JOptionPane; //Biblioteca para fzr input.

/**
 *
 * @author zander
 */

public class Corrente{
    public static void main(String[] args) {
        System.out.println("__________________________________________________________");

        ContaC Cliente = new ContaC();
        Cliente.setNumero(Integer.parseInt(JOptionPane.showInputDialog("insira o número da conta: ")));
        Cliente.setCliente(JOptionPane.showInputDialog("insira deu nome: ")); //input
        //Cliente.depositoConta(500);
        Cliente.setSaldo(Double.parseDouble(JOptionPane.showInputDialog("insira o saldo : ")));
        Cliente.setLimite(Double.parseDouble(JOptionPane.showInputDialog("insira o limite : ")));
        System.out.println("Nome do Cliente: " + Cliente.getCliente());
        System.out.println("Numero da conta: " + Cliente.getNumero());
        System.out.println("Limite: " + Cliente.getLimite());
        System.out.println("Saldo Anterior: " + Cliente.getSaldo());

        Cliente.saqueConta(Integer.parseInt(JOptionPane.showInputDialog("insira valor do saque: ")));
        System.out.println("Saldo Posterior: " + Cliente.getSaldo()); // caso seja maior, aparecera um block de transação.

        System.out.println("__________________________________________________________");

    }
}

        /*
        ContaC kelly = Cliente; /* Pode herdar as voids do pai e pode usar tudo que o pai tbm pode.

        kelly.setNumero(303244);
        kelly.setCliente("Kelly");
        //Cliente.depositoConta(500);
        kelly.setSaldo(1000);
        kelly.setLimite(1500);
        //Cliente.depositoConta(100);
        //Cliente.saqueConta();

        System.out.println("Nome do Cliente: " + kelly.getCliente());
        System.out.println("Numero da conta: " + kelly.getNumero());
        System.out.println("Limite: " + kelly.getLimite());
        System.out.println("Saldo Anterior: " + kelly.getSaldo());

        kelly.depositoConta(500);
        System.out.println("Saldo Posterior: " + kelly.getSaldo());

        System.out.println("__________________________________________________________");
    }
}

--> POR SER uma POO permite que diversos usuarios usem o programa ao mesmo tempo puxando diversar aplicações para cada um.*/