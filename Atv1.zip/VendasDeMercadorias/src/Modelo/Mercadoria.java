package Modelo;

public class Mercadoria {
    private double Custo;
    private double Frete;
    private double Despesas;
    private double Vender;

    public double valorBruto() {
        return (Custo + Frete )- Despesas;
    }

    public double valorLucro() {
        return Vender - valorBruto();
    }

    public double percentualDeLucro() {
        return ((valorLucro() / valorBruto()) * 100);

    }

    public double getCusto() {
        return Custo;
    }
    public void setCusto(double Custo) {
        this.Custo = Custo;
    }
    //
    public double getFrete() {
        return Frete;
    }
    public void setFrete(double Frete) {
        this.Frete = Frete;
    }
    //
    public double getDespesas() {
        return Despesas;
    }
    public void setDespesas(double Despesas) {
        this.Despesas = Despesas;
    }
    //
    public double getVender() {
        return Vender;
    }
    public void setVender(double Vender) {
        this.Vender = Vender;
    }
}
