package Visao;

import Modelo.Mercadoria;
import javax.swing.*;

public class Vendas {
    public static void main(String[] args) {
        Mercadoria produto = new Mercadoria();

        produto.setCusto(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o valor do custo da Mercadoria: ")));
        produto.setFrete(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o valor do custo do Frete: ")));
        produto.setDespesas(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o valor das Despesas: ")));
        produto.setVender(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o valor de Venda: ")));

        double percentualLucro = produto.percentualDeLucro();
        JOptionPane.showMessageDialog(null, "O percentual de lucro é: " + percentualLucro + "%");
    }
}


